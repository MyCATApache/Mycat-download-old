package org.opencloudb.sequence.handler;


/**
 * 通过Thirft客户端获取集群中心分配的全局ID
 * 
 * @author <a href="http://www.micmiu.com">Michael</a>
 * @time Create on 2013-12-25 上午12:15:48
 * @version 1.0
 */
public class ThirftClientSequenceHandler implements SequenceHandler {

	@Override
	public long nextId(String prefixName) {
		// TODO Auto-generated method stub
		return 0;
	}

}
