package org.opencloudb.route;


/**
 * route parse result info
 * 
 * @author wuzhih
 * 
 */
public class RouteParseInf {
	

	public void clear() {
		
	}

}
