package org.opencloudb.mpp;


public class DeleteParsInf extends SelectParseInf {
	/**
	 * delete table's name
	 */
	public String tableName;
	

}
