package org.opencloudb.mpp;

import org.opencloudb.route.RouteParseInf;

public class DDLParsInf extends RouteParseInf {
	/**
	 * table's name
	 */
	public String tableName;
}
