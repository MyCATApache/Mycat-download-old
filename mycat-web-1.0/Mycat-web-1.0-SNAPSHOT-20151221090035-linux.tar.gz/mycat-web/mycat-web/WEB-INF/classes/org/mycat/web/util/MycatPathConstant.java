package org.mycat.web.util;

public class MycatPathConstant {
	public static final String MYCAT_NAME_SPACE= "mycat";
	
	
	public static final String MYCAT_EYE= "/mycat-eye";
	
	public static final String MYSQL_GROUP=MYCAT_NAME_SPACE+"/mycat-mysqlgroup";
}
