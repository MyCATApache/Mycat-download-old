package jrds.probe;

public interface IndexedProbe {
	public String getIndexName();
}
