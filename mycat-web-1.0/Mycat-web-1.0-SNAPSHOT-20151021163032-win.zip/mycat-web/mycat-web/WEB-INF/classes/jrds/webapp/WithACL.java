package jrds.webapp;


public interface WithACL {
	public ACL getACL();
	public void addACL(ACL acl);
}
